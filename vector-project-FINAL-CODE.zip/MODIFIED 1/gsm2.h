// gsm2.h

#ifndef _GSM1_H_
#define _GSM1_H_
int valid(char *);
void int_allmodule(void);
void gsm_init(void);
void gsm_readmsg(void);
void newadmin(void);
#endif
