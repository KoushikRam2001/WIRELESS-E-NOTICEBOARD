//pin_function_defines.h

#define FUNC1 0 //GPIO
#define FUNC2 1 //ALT FUN
#define FUNC3 2 //ALT FUN
#define FUNC4 3 //ALT FUN
#define GPIO_IN 0X00000000
#define GPIO_OUT 0XFFFFFFFF

#define CFGPIN(WORD,PIN,FUNC) \
		WORD= ((PIN<16) ? \
			  ((WORD&(~(3<<PIN*2))) | (FUNC<<PIN*2)) :\
			  ((WORD&(~(3<<(PIN-16)*2))) | (FUNC<<(PIN-16)*2))) 
