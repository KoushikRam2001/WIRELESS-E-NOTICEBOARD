/* 74LS164.h */
void Init_74LS164(void);
void SIPO_74LS164_1(unsigned char );//Serial In Parallel Out(SIPO) Operations
void SIPO_74LS164_2(unsigned char );//Serial In Parallel Out(SIPO) Operations
void SIPO_74LS164_3(unsigned char );//Serial In Parallel Out(SIPO) Operations
void SIPO_74LS164_4(unsigned char );//Serial In Parallel Out(SIPO) Operations
