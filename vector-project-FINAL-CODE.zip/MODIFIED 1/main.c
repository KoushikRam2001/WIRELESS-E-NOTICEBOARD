#include "gsm2.h"

int main()
{
	int_allmodule();
	while(1)
	{
		gsm_readmsg();
    }
}
