#include <string.h>
#include "uart0.h"
#include "delay.h"
#include "i2c_eeprom.h"
#include "lcd.h"

#define L2 2
#define DL 100

extern char buff[200];
extern unsigned char i;
extern unsigned char r_flag;
extern unsigned int size;

void gsm_init()
{
	UART0_Str("AT\r\n");
	delay_ms(DL);
	r_flag=0;
	memset(buff,'\0',200);
	while(r_flag==0);   //wait for interrupt occur
	delay_ms(DL);
  if(  strstr(buff,"OK") )
  {
		Write_CMD_LCD(0x01);
		Write_str_LCD("AT=");
    Write_str_LCD(buff);
    delay_ms(DL);
  }
  else
  {
    Write_CMD_LCD(0x01);
    Write_str_LCD("AT=ERROR");
		Write_str_LCD(buff);
    delay_ms(DL);
    return;
  }

	UART0_Str("ATE0\r\n");
  r_flag=0;
	memset(buff,'\0',200);
	while(r_flag==0);   //wait for interrupt occur
  delay_ms(DL);
  if(strstr(buff,"OK"))
  {
    Write_CMD_LCD(0x01);
    Write_str_LCD("ATE0=");
    Write_str_LCD(buff);
    delay_ms(DL);
  }
  else
  {
    Write_CMD_LCD(0x01);
    Write_str_LCD("ERROR");
    delay_ms(DL);
    return;
  }

  UART0_Str("AT+CMGF=1\r\n");   // TO set SMS inputting mode
  r_flag=0;
	memset(buff,'\0',200);
	while(r_flag==0);   //wait for interrupt occur
  delay_ms(DL);
       
  if(strstr(buff,"OK"))
  {
    Write_CMD_LCD(0x01);
    Write_str_LCD("AT+CMGF=");
    Write_str_LCD(buff);
                delay_ms(DL);
        }
        else
        {
                Write_CMD_LCD(0x01);
                Write_str_LCD("ERROR");
                delay_ms(DL);
                return;
        }

        UART0_Str("AT+CMGD=1\r\n");  // To delete all read SMS
        r_flag=0;
				memset(buff,'\0',200);
				while(r_flag==0);   //wait for interrupt occur
        //delay_ms(DL);
       
        if(strstr(buff,"OK"))
        {
                Write_CMD_LCD(0x01);
                Write_str_LCD("AT+CMGD=");
                Write_str_LCD(buff);
                delay_ms(DL);
        }
        else
        {
                Write_CMD_LCD(0x01);
                Write_str_LCD("ERROR");
                delay_ms(DL);
                return;
        }

        UART0_Str("AT+CNMI=2,1,0,0,0\r\n");  // give alert when new SMS is arrived
        r_flag=0;
				memset(buff,'\0',200);
				while( r_flag==0 );   //wait for interrupt occur
        //delay_ms(DL);
        if(strstr(buff,"OK"))
        {
                Write_CMD_LCD(0x01);
                Write_str_LCD("AT+CNMI=");
                Write_str_LCD(buff);
                delay_ms(DL);
        }
        else
        {
                Write_CMD_LCD(0x01);
                Write_str_LCD("ERROR");
                delay_ms(DL);
                return;
        }
}

void gsm_alert()
{
 	char temp[15];
	UART0_Str("Testcase Invalid and inside gsm alert\r\n");
	Write_CMD_LCD(0x01);
    Write_str_LCD("ERROR");
    delay_ms(DL);
	if(strstr(buff,"!@#$%"))
	{
		int j=0;
		while(j<10)
		{
			temp[j]=buff[j+5];
			j++;
		}
		temp[j]='\0';
		UART0_Str("AT+CMGS=\"9714759707\"\r\n");
		UART0_Str("Unauthorised persion access your system:\r\n");
    UART0_Str(temp);    
		r_flag=0;
				memset(buff,'\0',200);
				while(r_flag==0);   //wait for interrupt occur
        //delay_ms(DL);
        if(strstr(buff,"OK"))
        {
                Write_CMD_LCD(0x01);
                Write_str_LCD("ATE0=");
                Write_str_LCD(buff);
                delay_ms(DL);
        }
        else
        {
                Write_CMD_LCD(0x01);
                Write_str_LCD("ERROR");
                delay_ms(DL);
                return;
        }

	}
	else
		UART0_Str("Passkey invalid\r\n");
}

void gsm_readmsg()
{
	char *temp=NULL,ch;
	while(U0LSR&0X01)
		ch=U0RBR;
	//UART0_Str("INSIDE READ\r\n");  // give alert when new SMS is arrived
	r_flag=0;
				memset(buff,'\0',200);
				while(r_flag==0);   //wait for interrupt occur
	  Write_CMD_LCD(0x01);
    Write_str_LCD("inside read");
    delay_ms(DL);
    if( strstr(buff,"SM") )
    {
    	UART0_Str("AT+CMGR=1\r\n");  // Read new SMS is arrived
		r_flag=0;
				memset(buff,'\0',200);
				while(r_flag==0);   //wait for interrupt occur
        //delay_ms(DL);
		UART0_Str(buff);
        if( (strstr(buff,"!@#$%")) && strstr(buff,"9714759707") )
        {
			temp=strstr(buff,"!@#$%");
			Write_CMD_LCD(0x01);
            Write_str_LCD((temp+5));
            delay_ms(DL);	
			size=strlen(temp+5)+1;		
			// update the latest masg into eeprom
			i2c_eeprom_page_write(0x50,0x0010,(u8*)temp+5,size);

            UART0_Str("AT+CMGD=1\r\n");  // To delete all read SMS                  
            r_flag=0;
				memset(buff,'\0',200);
				while(r_flag==0);   //wait for interrupt occur
            delay_ms(DL);
            
            if(strstr(buff,"OK"))
            {
            	Write_CMD_LCD(0x01);
                Write_str_LCD("OK");
                delay_ms(DL);
						}
			else
						{
            	Write_CMD_LCD(0x01);
                Write_str_LCD("AT+CMGD=ERROR");
                delay_ms(DL);
                return;
						}
		}
     	else
		{
			gsm_alert();				 				
            return;
    }
	}
}
