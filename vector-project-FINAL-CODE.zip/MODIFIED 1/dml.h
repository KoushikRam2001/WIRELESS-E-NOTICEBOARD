void display_char(unsigned char *,unsigned int);
