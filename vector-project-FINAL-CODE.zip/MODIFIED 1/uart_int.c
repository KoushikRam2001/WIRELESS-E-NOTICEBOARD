#include <LPC21xx.H>  /* LPC21xx definitions         */
#include "uart0.h"
#include"pin_function_defines.h"

char buff[200],dummy;
unsigned char i=0,ch,r_flag=0;

void InitUART0 (void)                      /* Initialize Serial Interface   */ 
{  
  CFGPIN(PINSEL0,0,1);
  CFGPIN(PINSEL0,1,1);
  //PINSEL0|=0x00000005;                    /* Enable RxD0 and TxD0          */
  U0LCR = 0x83;                            /* 8 bits, no Parity, 1 Stop bit */
  U0DLL = DIVISOR;                         /* 9600 Baud Rate @ CCLK/4 VPB Clock*/
  U0DLM = DIVISOR>>8;
  U0LCR = 0x03;                            /* DLAB = 0  */

  #if UART_INT_ENABLE > 0
  VICIntSelect = 0x00000000;               // IRQ
  VICVectAddr0 = (unsigned)UART0_isr;
  VICVectCntl0 = 0x20 | 6;                 /* UART0 Interrupt */
  VICIntEnable = 1 << 6;                   /* Enable UART0 Interrupt */
  U0IER = 0x03;                            /* Enable UART0 RX and THRE Interrupts */   
  #endif						
}

void UART0_isr(void) __irq
{
  if((U0IIR & 0x04)) //check if receive interrupt
  {
     r_flag=1;
     ch = U0RBR;     // Read to Clear Receive Interrupt 
     if(i<200)
       buff[i++]=ch;
  }
  else
  {		 
     dummy=U0IIR;                        //Read to Clear transmit interrupt
  } 
   VICVectAddr = 0;                      /* dummy write */
}

void UART0_Tx(char ch)                   /* Write character to Serial Port    */  
{ 
  while (!(U0LSR & 0x20));
  U0THR = ch;                
}

char UART0_Rx(void)    									/* Read character from Serial Port   */
{                     
  while (!(U0LSR & 0x01));
  return (U0RBR);
}

void UART0_Str(char *s)
{
   while(*s)
     UART0_Tx(*s++);
}
