#include <LPC21xx.h>

void delay_us(unsigned int i);
void delay_ms(unsigned int i);
void delay_s(unsigned int i);
