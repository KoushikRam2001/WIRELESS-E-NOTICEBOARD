#include <string.h>

#include "uart0.h"
#include "delay.h"
#include "i2c_eeprom.h"
#include "lcd.h"
#include "i2c.h"
#include "74LS164.h"
#include "dml.h"
#include "gsm2.h"

#define WAIT 100
#define DL 1000
#define L2 4

extern char buff[200];
extern unsigned char i,r_flag;
extern unsigned int size;
unsigned char ph[50],data[50];
char *temp2=NULL;
void newadmin()
{
            i2c_eeprom_seq_read(0x50,0X0000,(u8*)temp2,11);	
			i=0;
		    memset(buff,'\0',200);
		    //while(i<L2);   //wait for interrupt occur
			//LCD_print("int occur",1000);  //////////
    	    //delay_ms(WAIT);
		    //buff[i] = '\0';

			delay_s(3);	 
				
			UART0_Str("AT+CMGS=");
		    UART0_Tx('"');
		    UART0_Str((s8*)temp2);
		    UART0_Tx('"');
		    UART0_Str("\r\n");
		    delay_ms(1000);	  
			LCD_print("2nd mes wr strt",1000);///
			UART0_Str("Your Number: ");
			UART0_Str(temp2);
			UART0_Str(" is authorised");
			UART0_Str("\r\n");		
			UART0_Tx(0x1A);	     // cnt+z or 
			delay_ms(WAIT);	
			i=0;
			memset(buff,'\0',200);
			while(i<L2);   //wait for interrupt occur
			delay_ms(WAIT);
			buff[i] = '\0';
		
    if(strstr(buff,"OK") )
    {
     	Write_CMD_LCD(0x01);
       	Write_str_LCD("OK");
       	delay_ms(DL);
    }
    else
    {
       	Write_CMD_LCD(0x01);
       	Write_str_LCD(buff);
       	delay_ms(DL);
    }
		LCD_print("MSG sent!!",1000);
}

int valid(char *ptr)
{ 	   int k;
   for(k=0;k<10;k++)
   {
      if(ptr[k]<'0'||ptr[k]>'9')
      return 0;
   }
   return 1;
}
void int_allmodule()
{
	LCD_Init();
	Init_74LS164();
	InitUART0();
	init_i2c();
	set_i2c();
	gsm_init();
}

void print_dot(unsigned char*str)
{
	u8 i=0;
	for(i=0;i<14;i++)
	{
		display_char(str+i,500);
		if(r_flag)
			break;
	}
}

int gsm_cmd(char *str)
{
    i=0;
    memset(buff,'\0',200);
	UART0_Str(str);
    while(i<L2); 								  //wait for interrupt occur
    delay_ms(WAIT);
    buff[i] = '\0';
    if(strstr(buff,"OK") )
    {
			return 0;
    }
    else
    {
			return 1;
    }
}

void gsm_init()
{
	
	if(gsm_cmd("AT\r\n"))
	{
		LCD_print("AT=ERROR",1000);
	}
	
	if(gsm_cmd("ATE0\r\n"))
	{
		LCD_print("ATE0=ERROR",1000);
	}
	
	if(gsm_cmd("AT+CMGF=1\r\n"))   // TO set SMS inputting mode
	{
		LCD_print("AT+CMGF=ERROR",1000);
	}
        
	if(gsm_cmd("AT+CMGD=1\r\n"))  // To delete all read SMS
    {
		LCD_print("AT+CMGD=ERROR",1000);
	}
  
	if(gsm_cmd("AT+CNMI=2,1,0,0,0\r\n"))  // give alert when new SMS is arrived
    {
		LCD_print("AT+CNMI=ERROR",1000);
	}	
	LCD_print("gsm init done",1000);
}

void gsm_alert(u8 k)
{
 	s8 array[15],*ptr=NULL;
	u8 j=0;
	LCD_print("Testcase Invalid",1000);
	
		ptr=strstr(buff,"91")+2;
		while(j<10)
		{
			array[j]=ptr[j];
			j++;
		}
		array[j]='\0';
		
		/*UART0_Str("AT+CMGS=");
		UART0_Tx('"');
		UART0_Str((s8*)ph);
		UART0_Tx('"');
		UART0_Str("\r\n");
		delay_ms(1000);	 */  
		
		if(k==1)
		{
		   UART0_Str("AT+CMGS=");
		UART0_Tx('"');
		UART0_Str((s8*)ph);
		UART0_Tx('"');
		UART0_Str("\r\n");
		delay_ms(1000);	   
		
			UART0_Str("Be alert!! ");
			UART0_Str("Unauthorised person ");
			UART0_Str(array);
			UART0_Str(" trying to access your system !!");
			UART0_Str("\r\n");		
			UART0_Tx(0x1A);	     // cnt+z or 
			delay_ms(WAIT);
		}
		else if(k==2)
		{
			/*UART0_Str("Your Number: ");
			UART0_Str((s8*)ph);//TO BE WRITE PH
			UART0_Str(" is now un-authorised");
			UART0_Str("\r\n");		
			UART0_Tx(0x1A);	     // cnt+z or 
			delay_ms(WAIT);
			LCD_print("MSG-1 sent!!",1000);	///
			  //newadmin();	 */
			i2c_eeprom_seq_read(0x50,0X0000,(u8*)temp2,11);	
		/*	i=0;
		    memset(buff,'\0',200);
		    while(i<L2);   //wait for interrupt occur
			LCD_print("int occur",1000);  //////////
    	    delay_ms(WAIT);
		    buff[i] = '\0';

			delay_s(3);	   */
				
			UART0_Str("AT+CMGS=");
		    UART0_Tx('"');
		    UART0_Str((s8*)temp2);
		    UART0_Tx('"');
		    UART0_Str("\r\n");
		    delay_ms(1000);	  
			LCD_print("2nd mes wr strt",1000);///  */
			UART0_Str("Your Number: ");
			UART0_Str(temp2);
			UART0_Str(" is authorised");
			UART0_Str("\r\n");		
			UART0_Tx(0x1A);	     // cnt+z or 
			delay_ms(WAIT);	

		}
			i=0;
			memset(buff,'\0',200);
			while(i<L2);   //wait for interrupt occur
			delay_ms(WAIT);
			buff[i] = '\0';
		
    if(strstr(buff,"OK") )
    {
     	Write_CMD_LCD(0x01);
       	Write_str_LCD("OK");
       	delay_ms(DL);
    }
    else
    {
       	Write_CMD_LCD(0x01);
       	Write_str_LCD(buff);
       	delay_ms(DL);
    }
		LCD_print("MSG sent!!",1000);
}

void gsm_readmsg()
{
	r_flag=0;
    i=0;
	memset(buff,'\0',200);
	
	i2c_eeprom_seq_read(0x50,0X0000,ph,11);
	i2c_eeprom_seq_read(0x50,0X0014,data,size);

	while(i<6)   														
	{
		print_dot(data);
		LCD_print((s8*)data,1000);
	}
    delay_ms(WAIT);
    buff[i]='\0';
	
	if(strstr(buff,"CMTI") )
   {
		UART0_Str("AT+CMGR=1\r\n");
		i=0;
		memset(buff,'\0',200);
		while(i<70);                                  //wait for interrupt occur
		delay_ms(WAIT);
        buff[i] = '\0';
	
		if(strstr(buff,(const s8*)ph) )
  	    {
				//LCD_print(buff,3000);
				if(strstr(buff,"+-*/%") )
				{			
					temp2=strstr(buff,"+-*/%")+5;
				
					//0x17=0x14+3 // update the latest msg into eeprom
					i2c_eeprom_page_write(0x50,0x0014,(u8*)temp2,14);  
					LCD_print(temp2,2000);
					
					gsm_cmd("AT+CMGD=1\r\n");   // To delete SMS location on 1
				}
				else if(strstr(buff,"NUMCNG") )
				{
					temp2=strstr(buff,"NUMCNG")+6;
					temp2[10]='\0';
					// update the latest new mobile number into eeprom
					if(valid(temp2))
					{
					i2c_eeprom_page_write(0x50,0x0000,(u8*)temp2,10);  
					//LCD_print(temp2,2000);
					gsm_alert(2);
					//delay_ms(WAIT);
					//newadmin();
					}
					else
					{

					LCD_print("invalid num",1000);
					}
										
					gsm_cmd("AT+CMGD=1\r\n");   // To delete SMS location on 1
				}
				else if(strstr(buff,"RESET") )
	         	{			
				i2c_eeprom_page_write(0x50,0x000F,(u8*)"   ",3);		
				set_i2c();	
				gsm_cmd("AT+CMGD=1\r\n");   // To delete SMS location on 1
				//return;
		        }
				else
				{
					LCD_print("invalid msg format",1000);
					gsm_cmd("AT+CMGD=1\r\n");
				}
		}
    else
		{
		 	//LCD_print("k=1",1000);
			gsm_alert(1);				 				
			gsm_cmd("AT+CMGD=1\r\n");
      		return;
		}
	}
}
