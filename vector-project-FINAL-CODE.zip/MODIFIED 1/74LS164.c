/* 74LS164.c */
#include "defines.h"
#include "delay.h"
#include <LPC21xx.h>

#define SIN1  16     //p0.16
#define CP1   17     //p0.17
#define SIN2  18     //p0.18
#define CP2   19     //p0.19   
#define SIN3  20     //p0.20
#define CP3   21     //p0.21
#define SIN4  22     //p0.22
#define CP4   23     //p0.15

void Init_74LS164(void)
{
	IODIR0|=0x0000ff00; //ROWS as output
	IODIR0|=((1<<CP1|1<<SIN1)|(1<<CP2|1<<SIN2)|(1<<CP3|1<<SIN3)|(1<<CP4|1<<SIN4));  // COLs as output
}	

void SIPO_74LS164_1(unsigned char sDat) //Serial In Parallel Out(SIPO) Operations
{
   unsigned char i;
	
   for(i=0;i<8;i++)
   {
		   WRITEBIT(IOPIN0,SIN4,((sDat>>(7-i))&1));
		   SSETBIT(IOSET0,CP4);
		   delay_us(1);
		   SCLRBIT(IOCLR0,CP4);
   }
}	
	
void SIPO_74LS164_2(unsigned char sDat) //Serial In Parallel Out(SIPO) Operations
{
   unsigned char i;
	
   for(i=0;i<8;i++)
   {
		  WRITEBIT(IOPIN0,SIN3,((sDat>>(7-i))&1));
		  SSETBIT(IOSET0,CP3);
		  delay_us(1);
		  SCLRBIT(IOCLR0,CP3);
   }
}

void SIPO_74LS164_3(unsigned char sDat) //Serial In Parallel Out(SIPO) Operations
{
   unsigned char i;
	
   for(i=0;i<8;i++)
   {
		  WRITEBIT(IOPIN0,SIN2,((sDat>>(7-i))&1));
	 	  SSETBIT(IOSET0,CP2);
		  delay_us(1);
		  SCLRBIT(IOCLR0,CP2);
   }
}

void SIPO_74LS164_4(unsigned char sDat) //Serial In Parallel Out(SIPO) Operations
{
   unsigned char i;
   
   for(i=0;i<8;i++)
   {
		  WRITEBIT(IOPIN0,SIN1,((sDat>>(7-i))&1));
		  SSETBIT(IOSET0,CP1);
		  delay_us(1);
		  SCLRBIT(IOCLR0,CP1);
   }
}
