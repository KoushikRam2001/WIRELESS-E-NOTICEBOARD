//uart.c
#include <LPC21xx.h>
#include "Type.h"
#include "defines.h"
#include "pin_function_defines.h"
#include "uart_defines.h"

void uart_isr(void) __irq
{
	u8 t;
	t=U0IIR;
	t=(t>>1)&7;
	if(t==1)
	{	
	  CPLBIT(IOPIN0,UART_TX_STATUS_LED);
	}
	else if(t==2)
	{
		CPLBIT(IOPIN0,UART_RX_STATUS_LED);
		t=U0RBR;
	}
	VICVectAddr=0;
}

void InitUART(void)
{
	//cfg pin connect block for
	//p0.0 as TXD0
	CFGPIN(PINSEL0,TXD0,FUNC2);
	//p0.1 as RXD0
	CFGPIN(PINSEL0,RXD0,FUNC2);
	//cfg UART for 8data bit,no parity,1stopbit(8N1)
	U0LCR=1<<DLAB_BIT|WORD_LEN;
    //cfg baudrate generator
	U0DLM=LOADVAL>>8;
	U0DLL=LOADVAL;
	//disable dlab bit
	CLRBIT(U0LCR,DLAB_BIT);
	
	#if UART_INTS_EN > 0
	SETBIT(IODIR0,UART_TX_STATUS_LED);
	SETBIT(IODIR0,UART_RX_STATUS_LED);
	
	U0IER=1<<THRE_INT_EN_BIT|1<<RBR_INT_EN_BIT;
	//VICIntSelect=0;
	VICIntEnable=1<<6;
	VICVectCntl0=0x20|6;
	VICVectAddr0=(u32 ) uart_isr;
	#endif	
}

void UART_Tx(u8 sByte)
{
	//place byte into trasmit buffer
	U0THR=sByte;
	//wait until transmission completion status
	while(READBIT(U0LSR,TEMT_BIT)==0);
}

u8 UART_Rx(void)
{
	//wait until reception completion status
	while(READBIT(U0LSR,RDR_BIT)==0);
	//read & return recv data from recv buffer
	return U0RBR;
}

void UART_puts(s8 *s)
{
	while(*s)
		UART_Tx(*s++);
}

s8 * UART_gets(void)
{
	s32 i=0;
    static s8 a[200];
	while(1)
	{
		a[i]=UART_Rx();
		UART_Tx(a[i]);
		if((a[i]=='\r') || (a[i]=='\n'))
		{
			break;
		}
		i++;
	}
	a[i]='\0';
	return a;
}

void UART_U32(u32 n)
{
	s32 i,a[10];
	for(i=0;n;i++)
	{
		a[i]=n%10;
		n/=10;	
	}
	for(--i;i>=0;i--)
	{
	 	UART_Tx(a[i]+48);
	}		 	
}
void UART_S32(s32 n)
{
	if(n==0)
		UART_Tx('0');
	else
	{
 	if(n<0)
	{
		UART_Tx('-');
		n=-n;
	}
	UART_U32(n);
	}
}
void UART_F32(f32 f,u32 dp)
{
	u32 n;
	s32 i;
	if(f<0)
	{
	 	UART_Tx('-');
		f=-f;
	}
	n=f;
	UART_U32(n);
	UART_Tx('.');
	for(i=dp;i>=0;i--)
	{
	 	f=(f-n)*10;
		n=f;
		UART_U32(n);
	}
}
void UART_Bin(u32 n,u32 nbit)
{
	s32 i;
	for(i=nbit;i>=0;i--)
	{
		UART_Tx(((n>>i)&1)+48); 	
	}
}
void UART_Hex(u32 n)
{
 	s32 a[16],i;
	for(i=0;n;i++)
	{
		a[i]=((n%16)<10)? ((n%16)+48) : (((n%16)-10)+'A') ;
		n/=16;
	}
	for(--i;i>=0;i--)
		UART_Tx(a[i]);
}

