#include <LPC21xx.h>
#include<string.h>
#include "delay.h"
#include "uart.h"

char *buff;

int main()
{
	IODIR0=1<<8;
	InitUART(); 
	delay_s(5);  // initialise the GSM	
	UART_puts("AT\r\n");
	delay_s(2);
	UART_puts("ATE0\r\n");
	delay_s(2);
	UART_puts("AT+CMGF=1\r\n");	// TO set SMS inputting mode
	delay_s(2);
	UART_puts("AT+CMGD=1\r\n");  // To delete all read SMS
	delay_s(2);
	UART_puts("AT+CNMI=2,1,0,0,0\r\n");  // give alert when new SMS is arrived
	delay_s(2);
	while(1)
	{
	 buff=UART_gets();
	 if(strstr(buff,"SM"))
	 {
	 	IOSET0=1<<8;
		delay_s(5);
		IOCLR0=1<<8;
	 }
	}
}
